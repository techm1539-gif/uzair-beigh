# PixelCraft

A free starter UI for a Thumbnail / Poster Maker.

## Run on your computer

1. Install Python 3.10+.
2. Open terminal in this folder.
3. Run:
   pip install -r requirements.txt
4. Run:
   python app.py
5. Open http://127.0.0.1:5000

## Next upgrades

- Add real image uploads
- Add drag/drop canvas editing with Fabric.js or Konva.js
- Add PNG/JPG export
- Add user login/database
- Connect an AI image generation API
- Add payments/premium templates

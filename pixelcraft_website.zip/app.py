from flask import Flask, render_template, request, jsonify

app = Flask(__name__)

templates = [
    {"title":"Tech Review","category":"Tech","class":"tech","text":"TECH\nREVIEW"},
    {"title":"Gaming Setup","category":"Gaming","class":"gaming","text":"ULTIMATE\nGAMING SETUP"},
    {"title":"Travel Vlog","category":"Travel","class":"travel","text":"TRAVEL\nVLOG"},
    {"title":"Food Vlog","category":"Food","class":"food","text":"FOOD\nVLOG"},
    {"title":"Study Tips","category":"Education","class":"study","text":"STUDY\nTIPS"},
    {"title":"Business Ideas","category":"Business","class":"business","text":"BUSINESS\nIDEAS"},
]

@app.route("/")
def home():
    return render_template("index.html", templates=templates)

@app.route("/api/templates")
def get_templates():
    return jsonify(templates)

@app.route("/generate", methods=["POST"])
def generate():
    data = request.get_json(silent=True) or {}
    prompt = data.get("prompt", "").strip()
    if not prompt:
        return jsonify({"ok": False, "message": "Please enter a design idea."}), 400
    # Demo response. Connect an AI image/text API here later.
    return jsonify({
        "ok": True,
        "title": "AI Generated Design",
        "prompt": prompt,
        "message": "Demo design created. Connect an AI API for real image generation."
    })

if __name__ == "__main__":
    app.run(debug=True)

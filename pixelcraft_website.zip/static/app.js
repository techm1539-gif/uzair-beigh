function openEditor(name){document.getElementById("editorModal").classList.add("show");document.getElementById("canvasTitle").innerText=name.toUpperCase();document.getElementById("editText").value=name.toUpperCase();}
function closeModal(){document.getElementById("editorModal").classList.remove("show")}
function updateCanvas(){document.getElementById("canvasTitle").innerText=document.getElementById("editText").value.toUpperCase()}
function changeSize(v){document.getElementById("canvasTitle").style.fontSize=v+"px"}
function align(v){document.getElementById("canvas").style.textAlign=v}
function openAI(){document.getElementById("ai").scrollIntoView({behavior:"smooth"});document.getElementById("prompt").focus()}
async function generateAI(){
 const prompt=document.getElementById("prompt").value;
 const result=document.getElementById("aiResult");
 if(!prompt.trim()){result.innerHTML="<p>Please enter a design idea.</p>";return}
 result.innerHTML="<p>Creating your concept...</p>";
 const r=await fetch("/generate",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({prompt})});
 const data=await r.json();
 result.innerHTML=data.ok?`<p><b>${data.title}</b><br>${data.message}</p>`:`<p>${data.message}</p>`;
}
function searchTemplates(){
 const q=document.getElementById("searchInput").value.toLowerCase();
 document.querySelectorAll(".template").forEach(x=>x.style.display=(!q||x.innerText.toLowerCase().includes(q))?"block":"none");
 document.getElementById("templates").scrollIntoView({behavior:"smooth"});
}
window.onclick=e=>{if(e.target.id==="editorModal")closeModal()}
